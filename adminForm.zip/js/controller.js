admin.controller("adminCtrl", function($scope, $http, $rootScope, $state, $mdDialog) {
  $scope.operation = "Submit";
  var cityId = "123";
  var locationId = "456";
  var userId = "132214988410";
  var VENDORS = 'vendors/'+cityId+'/'+locationId;
  var VENDORS_VERSION = 'vendorsVersion/' +cityId+ '/' +locationId;
  $scope.vendorID = "";
  $scope.times = "";
  $scope.editItem = false;
  $scope.vendor = {
    vendorName: "null",
    vendorCategory: "null",
    featuredVendor: {
      active: false,
      placement: "null",
      position: "null"  
    },
    gender: "null",
    address: {
      locationId: "null",
      cityId: "null",
      addressLine1: "null",
      addressLine2: "null",
      landmark: "null",
      latitude: "null",
      longitude: "null",
      pinCode: "null",  
    },
    contactDetails: {
      primaryContactPerson: "null",
      primaryLandlineNumber: "null",
      primaryMobileNumber: "null",
      primaryEmailId: "null",

      secondaryContactPerson: "null",
      secondaryLandlineNumber: "null",
      secondaryMobileNumber: "null",
      secondaryEmailId: "null",

      complaintContactPerson: "null",
      complaintLandlineNumber: "null",
      complaintMobileNumber: "null",
      complaintEmailId: "null", 
    }, 
    ratings: "null",
    working: {
      monday: {
        active: false,
        start: "null",
        end: "null"
      },
      tuesday: {
        active: false,
        start: "null",
        end: "null"
      },
      wednesday: {
        active: false,
        start: "null",
        end: "null"
      },
      thursday: {
        active: false,
        start: "null",
        end: "null"
      },
      friday: {
        active: false,
        start: "null",
        end: "null"
      },
      saturday: {
        active: false,
        start: "null",
        end: "null"
      },
      sunday: {
        active: false,
        start: "null",
        end: "null"
      }
    },
    amenities: {
      ac: false,
      parking: false,
      teaCoffee: false,
      ccAccepted: false,
      wifi: false
    },
    services: "null",
    versionNo: "null",
    subVersion: "null",
    versionId: "null",
    createdDate: "null",
    updatedDate: "null",
    updatedBy: "null",
    specialOffer: "null"
  };
  $scope.vendorService = {
    menuId: "null",
    serviceName: "null",
    duration: "null",
    male: false,
    female: false,
    listPrice: "null",
    customerPrice: "null"
  };
  $scope.vendorSpecialOffer = {
    details: "null"
  }
  $scope.vendorVersion = {
    //This is the foreign Key
    versionNo: "null",
    id: "null",
    subVersion: "null",
    active: false,
    live: false,
    editable: true,
    createdBy: "null",
    createdDate: "null",
    submittedDate: "null",
    liveTime: "null",
    comments: "null",
  }
  $scope.vendorVersionComment = {
    createdBy: "null",
    userName: "null",
    createdTime: "null",
    text: "null"
  }
  $scope.vendors =[];
  /* City/Location Dummy Value */
  $scope.submit = function() {
    $scope.vendor.address.cityId = cityId;
    $scope.vendor.address.locationId = locationId;
    $scope.vendor.createdBy = userId;
    $scope.vendor.createdDate = getDateTime();
    $scope.vendor.updatedDate = getDateTime();
    
    $scope.vendorVersion.createdBy = userId;
    $scope.vendorVersion.createdDate = getDateTime();
    $scope.vendorVersion.submittedDate = getDateTime();
    
    save($scope.vendor, $scope.vendorVersion);
  }
  $scope.arpit = {};

  $scope.test = {
    id: "7777"
  }

  console.log($scope.test.name);
$scope.savefb = function(){
   var newPostKey = database.ref().child('posts').push().key;
     var updates = {};
  

       var postData = {
    author: $scope.arpit.name,
    uid: $scope.arpit.id
  }

  console.log(postData);

  updates['/posts/' + newPostKey] = postData;
 database.ref().update(updates);
}
  function save(vendor, vendorVersion) { 
    var key = database.ref().child(VENDORS).push().key;
    console.log(key);
    // database.ref(VENDORS)
    //   .push({active: vendor})
    //   .then(function(vendorData) {
    //     $scope.vendorID = vendorData.key;
    //     //form is saved now save it's version
    //     database.ref(VENDORS_VERSION+'/'+vendorData.key+'/active/')
    //       .update(vendorVersion)
    //       .then(function(versionData){
    //         console.log(versionData.val());
    //       })
    //       .catch(function(error) {
    //         console.log(error);
    //       })
    //     ;
    //     $state.go('/services');
    //   })
    //   .catch(function(error) {
    //     console.log(error);
    //   });
  }
  function update(vendor, vendorVersion, vendorId, ev) {
    database.ref(VENDORS_VERSION+'/'+vendorId+'/active/').once('value', function(snapshot) {
      if(snapshot.val().editable == true) {
        database.ref(VENDORS+'/'+vendorId+'/active/').once('value', function(snapshot) {
          database.ref(VENDORS+'/'+vendorId+'/previous/')
            .push(snapshot.val())
            .then(function(data) {
              database.ref(VENDORS_VERSION+'/'+vendorId+'/active/').once('value', function(snapshot) {
                database.ref(VENDORS_VERSION+'/'+vendorId+'/previous/')
                  .push(snapshot.val())
                  .then(function(data) {
                    console.log(data);
                });
              });
              var update = {};
              update[VENDORS+'/'+vendorId+'/active/'] = vendor;
              update[VENDORS_VERSION+'/'+vendorId+'/active/'] = vendorVersion;
              database.ref().update(update).then(function(data) {
                console.log(data);
              });
          });
        });
      }
      else {
        $mdDialog.show(
          $mdDialog.alert()
            .parent(angular.element(document.querySelector('body')))
            .clickOutsideToClose(true)
            .title('Warning')
            .textContent('This Version is non Editable')
            .ariaLabel('Alert Dialog Demo')
            .ok('Got it!')
            .targetEvent(ev)
        );
      }
    });
  }
  function getDateTime() {
      var now     = new Date(); 
      var year    = now.getFullYear();
      var month   = now.getMonth()+1; 
      var day     = now.getDate();
      var hour    = now.getHours();
      var minute  = now.getMinutes();
      var second  = now.getSeconds(); 
      if(month.toString().length == 1) {
          var month = '0'+month;
      }
      if(day.toString().length == 1) {
          var day = '0'+day;
      }   
      if(hour.toString().length == 1) {
          var hour = '0'+hour;
      }
      if(minute.toString().length == 1) {
          var minute = '0'+minute;
      }
      if(second.toString().length == 1) {
          var second = '0'+second;
      }   
      var dateTime = year+'/'+month+'/'+day+' '+hour+':'+minute+':'+second;   
      return dateTime;
  }
  function serviceSave(vendorId, vendorServiceType, vendorService) {
    database.ref(VENDORS+'/'+ vendorId+ '/' + 'services/' + vendorServiceType)
      .set({services: vendorServiceType})
      .then(function(data) {
        database.ref(VENDORS)
          .set({vendorServiceType: vendorService})
          .then(function(dataTwo) {
            console.log(dataTwo);
          });
      });
  }
  function getVendors() {
    $scope.vendors = [];
    database.ref(VENDORS).once('value', function(snapshot) {
      console.log(snapshot.val());
      snapshot.forEach(function(data) {
        $scope.vendors.push({
          key: data.key,
          val: data.val().active
        });
      });
      console.log($scope.vendors);
    });
  }
  function submitRetrieve() {
    if($scope.operation === 'Submit') {
      angular.element(document.getElementById('vendorRetrieve')).addClass('ng-hide');
      angular.element(document.getElementById('vendorUpdateButton')).addClass('ng-hide');
      angular.element(document.getElementById('vendorSubmit')).removeClass('ng-hide');
      angular.element(document.getElementById('vendorSubmitButton')).removeClass('ng-hide');
    }
    else {
      angular.element(document.getElementById('vendorSubmit')).addClass('ng-hide');
      angular.element(document.getElementById('vendorSubmitButton')).addClass('ng-hide');
      angular.element(document.getElementById('vendorRetrieve')).removeClass('ng-hide');
      angular.element(document.getElementById('vendorUpdateButton')).removeClass('ng-hide');
    }
  }
  function fillValues(vendorId) {
    database.ref(VENDORS+'/'+vendorId+'/active/')
      .once('value', function(snapshot) {
        console.log(snapshot.val());
        $scope.vendor = snapshot.val();
        $scope.vendor.services = null;
        console.log(snapshot.val().services);
        $scope.vendorServices = snapshot.val().services;
        console.log($scope.vendorServices);
      });
  }
  $scope.fillValues = function(key) {
    $scope.vendorID = key;
    fillValues(key);
  }
  $scope.update = function(ev) {
    $scope.vendor.updatedDate = getDateTime();
    
    $scope.vendorVersion.submittedDate = getDateTime();
    
    update($scope.vendor, $scope.vendorVersion, $scope.vendorID, ev);
  }
  //save($scope.vendor, $scope.vendorVersion);
  //update({temp:"null"}, $scope.vendorVersion, '-KKN4uWo3s90uleixBo8');
  $scope.master_start = function() {
    $scope.vendor.working.sunday.start = $scope.data.allstart;
    $scope.vendor.working.monday.start = $scope.data.allstart;
    $scope.vendor.working.tuesday.start = $scope.data.allstart;
    $scope.vendor.working.wednesday.start = $scope.data.allstart;
    $scope.vendor.working.thursday.start = $scope.data.allstart;
    $scope.vendor.working.friday.start = $scope.data.allstart;
    $scope.vendor.working.saturday.start = $scope.data.allstart;

  }
  $scope.master_end = function() {
    $scope.vendor.working.sunday.end = $scope.data.allend;
    $scope.vendor.working.monday.end = $scope.data.allend;
    $scope.vendor.working.tuesday.end = $scope.data.allend;
    $scope.vendor.working.wednesday.end = $scope.data.allend;
    $scope.vendor.working.thursday.end = $scope.data.allend;
    $scope.vendor.working.friday.end = $scope.data.allend;
    $scope.vendor.working.saturday.end = $scope.data.allend;

  }
  $http.get("data/times.json").success(function(response) {
    $scope.times = response.times;
    console.log(response.times);

  });
  $http.get("data/states.json").success(function(response) {
    $scope.states = response;
    console.log(response);
  });
  $scope.findCityForState = function() {
    console.log($scope.vendor.state);
    angular.forEach($scope.states, function(value, key) {
      if (key == $scope.vendor.state)
        $scope.cities = value;
    });
    console.log($scope.cities);
  }
  submitRetrieve();
  $scope.toggle = function() {
    submitRetrieve();
    getVendors();
  }
});

