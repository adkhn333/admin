var admin = angular.module('admin', ['ui.router', 'ngMaterial', 'ngMessages']);
var config = {
    apiKey: "AIzaSyD3GO4-9oSqSxrhhF-Zcq7FZYdEFsWOGmw",
    authDomain: "temp-df1a5.firebaseapp.com",
    databaseURL: "https://temp-df1a5.firebaseio.com",
    storageBucket: "temp-df1a5.appspot.com",
  };
firebase.initializeApp(config);
var database = firebase.database();
/*
admin.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider
      .when('/basic', {
        templateUrl: '../templates/basic.html',
        controller: 'adminCtrl'
      })
      .when('/services', {
        templateUrl: '../templates/services.html',
        controller: 'serviceCtrl'
      })

    .otherwise({
      redirectTo: '/basic'
    });
  }
]);
*/
admin.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider
    .state('/basic', {
      url: '/basic',
      views: {
        'main-view': {
          templateUrl: 'templates/basic.html',
          controller: 'adminCtrl'
        }
      }
    })
    .state('/services', {
      url: '/services',
      views: {
        'main-view': {
          templateUrl: 'templates/services.html',
          controller: 'serviceCtrl'
        }
      }
    })
    ;
  $urlRouterProvider.otherwise('/basic');
});

var getVendorType = function(x) {
  if (x == 1)
    return "Silver";
  else if (x == 2)
    return "Gold";
  else
    return "Platinum";

}

var getVendorGender = function(x) {
  if (x == 1)
    return "Male";
  else if (x == 2)
    return "Female";
  else if (x == 3)
    return "Unisex";
  else
    return "Kids";

}



  