admin.controller("serviceCtrl", function($scope, $rootScope, $stateParams, $mdDialog) {
    $scope.editItem = false;
    $scope.vendorListItem = {
        key: "",
        name: ""
    }
    $scope.vendorID = "";
    $scope.tvendorListItem = {
        serviceName: "null",
        serviceSubCategory: "null",
        male: false,
        female: false,
        kids: false,
        duration: "null",
        listPrice: "null",
        fab2uPrice: "null",
        customerPrice: "null",
    }
    $scope.vendorID = "";
    $scope.vendorList = [];
    $scope.tvendorService = {};
    $scope.vendorServices = [];
    $scope.vendorServicesFinal = {};
    var cityId = "123";
    var locationId = "456";
    var userId = "132214988410";
    var VENDORS = 'vendors/'+cityId+'/'+locationId;
    var VENDORS_VERSION = 'vendorsVersion/' +cityId+ '/' +locationId;
    getVendors();
    function getVendors() {
        $scope.vendors = [];
        database.ref(VENDORS+'/').once('value', function(snapshot) {
            console.log(snapshot.val());
            $scope.vendorList = [];
            snapshot.forEach(function(data) {
                console.log(data.val());
                $scope.vendorListItem = {
                    key: data.key,
                    name: data.val().active.vendorName,
                };
                $scope.vendorList.push($scope.vendorListItem);
                console.log($scope.vendors);
            });
        });
    }
    $scope.fillValues = function(key) {
        $scope.vendorID = key;
        $scope.vendorServices = [];
        $scope.vendorID = key;
        database.ref(VENDORS+'/'+key+'/'+'/active/services')
        .once('value', function(snapshot) {
            console.log(snapshot.val());
            snapshot.forEach(function(data) {
                data.forEach(function(obj) {
                    console.log(obj.val());
                    $scope.vendorServices.push(obj.val());
                });
            });
        });
    }
    $scope.services = {
        HairNCut: '123',
        Facials: '456',
        Gym: '789'
    };
    $scope.serviceSubCategories = {
        '123': [
            'Hair Cut, Blow Dry Ladies',
            'Hair Cut Gents',
            'Rebonding/Smoothening'
        ],
        '456': [
            'Casmara Facial',
            'O 3 Facial',
            'Lotus Whitening Facial'
        ]
    };
    $scope.pushServiceInMain = function() {
        console.log($scope.tvendorService);
        $scope.vendorServices.push($scope.tvendorService);
        console.log($scope.vendorServices);
        $scope.tvendorService = {};
        $scope.vendorServiceForm.$setPristine();
        $scope.vendorServiceForm.$setUntouched();
    }
    $scope.reset = function() {
        $scope.tvendorService = {};
        $scope.vendorServiceForm.$setPristine();
        $scope.vendorServiceForm.$setUntouched();
    }
    $scope.submit = function(ev) {
        var vendorID = $scope.vendorID;
        database.ref(VENDORS_VERSION+'/'+vendorID+'/active/').once('value', function(snapshot) {
            if(snapshot.val().editable == true) {
                angular.forEach($scope.vendorServices, function(data) {
                    var temp = {};
                    temp = {
                        serviceName: data.serviceName,
                        menuTitle: data.menuTitle,
                        male: data.male,
                        female: data.female,
                        kids: data.kids,
                        duration: data.duration,
                        listPrice: data.listPrice,
                        fab2uPrice: data.fab2uPrice,
                        customerPrice: data.customerPrice
                    }
                    database.ref(VENDORS+'/'+$scope.vendorID+'/active/services/')
                    .set(null)
                    .then(function(obj) {
                        database.ref(VENDORS+'/'+$scope.vendorID+'/active/services/'+data.serviceName)
                        .push(temp)
                        .then(function(data) {
                            $scope.vendorServices = [];
                            console.log(data);
                        })
                        .catch(function(error) {
                            console.log(error);
                        });
                    })
                    .catch(function(error) {
                        console.log(error);
                    });
                });
                
            }
            else {
                $mdDialog.show(
                $mdDialog.alert()
                    .parent(angular.element(document.querySelector('body')))
                    .clickOutsideToClose(true)
                    .title('Warning')
                    .textContent('This Version is non Editable')
                    .ariaLabel('Alert Dialog Demo')
                    .ok('Got it!')
                    .targetEvent(ev)
                );
            }
        });
    }
    $scope.editVendorService = function(service) {
        $scope.editItem = true;
        //$scope.vendorServices.splice($scope.vendorServices.indexOf(service),1);
        console.log(service);
        $scope.tvendorService = angular.extend({},$scope.tvendorService,service);
        $scope.tvendorService.cIndex = $scope.vendorServices.indexOf(service);
        console.log($scope.tvendorService.cIndex);
        $scope.vendorServiceForm.$setDirty();
    }
    $scope.updateServiceInMain = function(index) {
        console.log(index);
        $scope.vendorServices.splice(index,1);
        $scope.tvendorService.cItem = undefined;
        $scope.vendorServices.push($scope.tvendorService);
        console.log($scope.vendorServices);
        $scope.tvendorService = {};
        $scope.vendorServiceForm.$setPristine();
        $scope.vendorServiceForm.$setUntouched();
    }
    $scope.removeVendorService = function(service) {
        $scope.vendorServices.splice($scope.vendorServices.indexOf(service),1);
    }
});